import 'dart:async';

import 'dart:typed_data';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';

import 'drawers/newsidebar.dart';

class dashboard extends StatefulWidget {
  @override
  _dashboard createState() => _dashboard();
}

class _dashboard extends State<dashboard> {
  Container horiQuiz(String image, String name) {
    return Container(
        width: 200,
        height: 250,
        child: GestureDetector(
          onTap: () {
            // Navigator.push(
            //     context,
            //     MaterialPageRoute(
            //       builder: (context) => link,
            //     ));
          },
          child: Card(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(40.0)),
            margin: EdgeInsets.all(5.0),
            child: Wrap(
              children: [
                Center(
                  child: Container(
                    height: 120,
                    width: 120,
                    child: Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(100.0)),
                      child: Image.network(
                        image,
                        fit: BoxFit.fill,
                        height: 100,
                        width: 100,
                      ),
                    ),
                  ),
                ),
                ListTile(
                  title: Text(name),
                  subtitle: Text('Quiz'),
                ),
              ],
            ),
          ),
        ));
  }

  @override
  Widget imageSliderCarousel = Padding(
      padding: EdgeInsets.all(7.50),
      child: Container(
        height: 250.0,
        child: ClipRRect(
            borderRadius: BorderRadius.circular(20.0),
            child: Carousel(
              boxFit: BoxFit.fill,
              images: [
                Corosol(1),
                Corosol(2),
                Corosol(3),
                Corosol(4),
                Corosol(5),
              ],
              indicatorBgPadding: 1.0,
            )),
      ));
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFE8EAF6),
      drawer: Maindrawer(),
      body: CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            centerTitle: true,
            title: Text("Dashboard"),
            pinned: true,
            floating: true,
            expandedHeight: 200,
            flexibleSpace: FlexibleSpaceBar(
              centerTitle: true,
              title: nameView(),
              background: Image(
                image: AssetImage(
                  'images/CracKer.png',
                ),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SliverList(
              delegate: SliverChildListDelegate([
            Container(
              height: 179,
              child: imageSliderCarousel,
            ),
            SizedBox(
              height: 30,
              child: Center(
                child: Text("Play Quiz earn and Learn"),
              ),
            ),
            Container(
              height: 250,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: <Widget>[
                  horiQuiz(
                      'https://images.financialexpress.com/2017/05/wipro.jpg',
                      'Wipro'),
                  horiQuiz(
                      'https://capgeminielection.azurewebsites.net/capgemini-icon%20darkest.png',
                      'Capzamni'),
                  horiQuiz(
                      'https://edu.kanban.university/sites/default/files/styles/large/public/company_logo/edu_website_logo_cognizant-01.png?itok=0Wf_nJRn',
                      'Cognizant'),
                  horiQuiz(
                      'https://img.icons8.com/plasticine/2x/arrow.png', 'More')
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.all(10.0),
              height: 250,
              child: Card(
                  elevation: 10,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(50.0)),
                  child: Corosol(6)),
            )
          ])),
        ],
      ),
    );
  }

  Stream<QuerySnapshot> getuserdataSnapShot(BuildContext context) async* {
    Firestore _firestore = Firestore.instance;
    FirebaseAuth _firebase = FirebaseAuth.instance;
    FutureOr<String> uid =
        await _firebase.currentUser().then((user) => user.uid);

    yield* _firestore
        .collection("crackerdetails")
        .document(uid.toString())
        .collection("using")
        .snapshots();
  }

  Widget nameCard(BuildContext context, DocumentSnapshot using) {
    return Title(
        color: Colors.deepOrangeAccent,
        child: Center(
            child: Container(
                margin: EdgeInsets.only(top: 150),
                child: Column(
                  children: [
                    using['name'] == null
                        ? Text("hello Cracker")
                        : Text("Hello," + using['name']),
                  ],
                ))));
  }

  Widget nameView() {
    return StreamBuilder(
      stream: getuserdataSnapShot(context),
      builder: (context, snapshot) {
        if (!snapshot.hasData)
          return Text(  
            'Loading your details',
            textAlign: TextAlign.center,
          );
        return ListView.builder(
            itemCount: snapshot.data.documents.length,
            itemBuilder: (BuildContext context, int index) =>
                nameCard(context, snapshot.data.documents[index]));
      },
    );
  }
}

//Corosol Class................................................................

class Corosol extends StatefulWidget {
  int _index;
  Corosol(int index) {
    this._index = index;
  }

  @override
  _CorosolState createState() => _CorosolState();
}

class _CorosolState extends State<Corosol> {
  Uint8List imageFile;
  StorageReference referance =
      FirebaseStorage.instance.ref().child("DashBoardCorasol");
  getCorosol() {
    referance
        .child("index_${widget._index}.gif")
        .getData(4 * 1024 * 1024)
        .then((value) {
      this.setState(() {
        imageFile = value;
      });
    });
    referance
        .child("index_${widget._index}.png")
        .getData(4 * 1024 * 1024)
        .then((value) {
      this.setState(() {
        imageFile = value;
      });
    });

    referance
        .child("index_${widget._index}.jpg")
        .getData(4 * 1024 * 1024)
        .then((value) {
      this.setState(() {
        imageFile = value;
      });
    });
  }

  Widget ViewCoresal() {
    if (imageFile == null) {
      //   return Image.asset("images/Crackload.gif", fit: BoxFit.cover);
    } else {
      return Image.memory(
        imageFile,
        fit: BoxFit.cover,
      );
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCorosol();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ViewCoresal(),
    );
  }
}

//clas heading

class Heading extends StatelessWidget {
  String name;
  Heading(name);
  @override
  Widget build(BuildContext context) {
    return SliverList(
        delegate: SliverChildListDelegate(<Widget>[
      Container(
        child: Text(name),
      )
    ]));
  }
}
