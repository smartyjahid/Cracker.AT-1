import 'package:flutter/material.dart';
import 'package:flutter_plugin_pdf_viewer/flutter_plugin_pdf_viewer.dart';

class Viewpdf extends StatefulWidget {
  @override
  _ViewpdfState createState() => _ViewpdfState();
}

class _ViewpdfState extends State<Viewpdf> {
  PDFDocument doc;

  @override
  Widget build(BuildContext context) {
    String data = ModalRoute.of(context).settings.arguments;
    viewNow() async {
      doc = await PDFDocument.fromURL(data);
      setState(() {});
    }

    // ignore: missing_return
    Widget loading() {
      viewNow();
      if (doc == null) {
        return Text("loading");
      }
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black45,
        title: Text("pdf viewer"),
      ),
      body: doc == null ? loading() : PDFViewer(document: doc),
    );
  }
}
