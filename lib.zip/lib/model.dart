class Model {
  String link, name;
  Model(this.link, this.name);
}