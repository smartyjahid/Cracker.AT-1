class CategoryModel {
  String catagoryname;
  String imageurl;
}
