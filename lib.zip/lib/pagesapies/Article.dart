import 'dart:convert';

import 'package:dimagkharab/pagesapies/Artical_model.dart';
import 'package:flutter/cupertino.dart';

import 'package:http/http.dart' as http;

class NewsArt {
  List<Articlemode> newsart = [];

  Future<void> geturl() async {
    String url =
        'http://newsapi.org/v2/top-headlines?country=in&categor&apiKey=f04c69b93ed6491db04eff15ad995be7';

    var respone = await http.get(url);

    var jashon = jsonDecode(respone.body);
    if (jashon['status'] == "ok") {
      jashon["articles"].forEach((element) {
        if (element["urlToImage"] != null && element["description"] != null) {
          Articlemode articlmodel = Articlemode(
            title: element['title'],
            author: element['author'],
            description: element['description'],
            url: element["url"],
            urlToImage: element['urlToImage'],
            content: element["content"],
          );
          newsart.add(articlmodel);
        }
      });
    }
  }
}

class CategoryNewsArt {
  List<Articlemode> newsart = [];

  Future<void> geturl(String category) async {
    String url =
        'http://newsapi.org/v2/top-headlines?country=in&sources=techcrunch&apiKey=API_KEY';

    var respone = await http.get(url);

    var jashon = jsonDecode(respone.body);
    if (jashon['status'] == "ok") {
      jashon["articles"].forEach((element) {
        if (element["urlToImage"] != null && element["description"] != null) {
          Articlemode articlmodel = Articlemode(
            title: element['title'],
            author: element['author'],
            description: element['description'],
            url: element['url'],
            urlToImage: element['urlToImage'],
            content: element["content"],
          );
          newsart.add(articlmodel);
        }
      });
    }
  }
}
