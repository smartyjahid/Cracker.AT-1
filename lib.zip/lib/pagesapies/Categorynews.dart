import 'package:flutter/material.dart';

class Categorynews extends StatefulWidget {
  @override
  _CategorynewsState createState() => _CategorynewsState();
}

class _CategorynewsState extends State<Categorynews> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}  