//Experince

import 'package:dimagkharab/newsapi.dart';
import 'package:flutter/material.dart';

import 'package:flutter/cupertino.dart';

class About extends StatefulWidget {
  @override
  _AboutState createState() => _AboutState();
}

class _AboutState extends State<About> {
  dess() {
    TextStyle(
      color: Colors.black26,
      fontFamily: "Roboto",
      fontWeight: FontWeight.w700,
      fontSize: 200,
    );
  }

  dess1() {
    TextStyle(
      color: Colors.yellowAccent,
      fontFamily: "Abel",
      fontWeight: FontWeight.w200,
      fontSize: 80,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(35.0),
        child: Container(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                  child: Text(
                "Cracker.AT",
                style: TextStyle(
                  color: Colors.redAccent,
                  fontFamily: "Abel",
                  fontWeight: FontWeight.w200,
                  fontSize: 40,
                ),
              )),
              SizedBox(
                height: 20,
              ),
              Text(
                "About",
                style: TextStyle(
                  color: Colors.grey,
                  fontFamily: "Roboto",
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Text("Disclaimer\n",style: TextStyle(
      color: Colors.grey,
      fontFamily: "Roboto",
      fontWeight: FontWeight.w700,
      fontSize: 20,
    ),),
              Text(
                  "Cracker.AT is an indian initiative work under 'SelfDeveloper.com'"
                  " this Application is basically based on education purpose.\n here you will "
                  "find The creteria of Several Compnay's and excitic tips & tricks to Crack "
                  "The Compnies exam And many More....."
                  "\n"
                  "\n"),
              Text(
                "Team Member's",
                textAlign: TextAlign.start,
                style: TextStyle(
                  color: Colors.black26,
                  fontFamily: "Roboto",
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                ),
              ),
              Container(
                child: Card(
                  child: Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Icon(
                          Icons.person,
                          size: 100,
                          color: Colors.grey,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 20),
                          child: Text("\n       Tanya Prowal\n"
                              "(Director&Founder of \n Cracker.At)\n"
                              "Role: Head Engineer &\n         Software Tester  "),
                        )
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                child: Card(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(
                        Icons.person,
                        size: 100,
                        color: Colors.green,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 20),
                        child: Text("\n        Jahid Khan\n"
                            "(Co-founder of Cracker.At)\n"
                            "Role: Head Engineer &\n     Software Manager "),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                child: Card(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(
                        Icons.person,
                        size: 100,
                        color: Colors.blueAccent,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 20),
                        child: Text("\n        Aaqib Shafi Dar\n"
                            "(Co-founder of Cracker.At)\n"
                            "Role:Software Analytics ,\n       UI designing&\n"
                            "         Marketing Head \n"),
                      )
                    ],
                  ),
                ),
              ),
              Container(
                child: Card(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(
                        Icons.person,
                        size: 100,
                        color: Colors.blueGrey,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 20),
                        child: Text("\n        Ayush Kumar\n"
                            "(Co-founder of Cracker.At)\n"
                            "Role:Support Manager,\n      Data Analysis\n"),
                      )
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Privacy  and policy",
                textAlign: TextAlign.start,
                style: TextStyle(
                  color: Colors.black26,
                  fontFamily: "Roboto",
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                ),
              ),
              Text(
                "\n\nUpdated at 2020-12-04,\n\n\nCracker.AT('we','our','or','us')"
                "is committed to protectecting you privacy. \nthis privacy policy explain how your personal information is Collected ,used and Disclosed by Cracker.AT \n"
                "\n"
                "This privacy policy applies to our Application 'Cracker.At' "
                "and its associated subdomains(Selfdeveloper's) "
                "by accessing or using our Services, you Singnify that yo have read,understood and Agree to our collection ,"
                "Storage,use and disclosure of your personal information"
                "as described is ths privacy policy and our terms of Services",
                style: TextStyle(
                  color: Colors.redAccent,
                  fontFamily: "Abel",
                  fontWeight: FontWeight.w200,
                  fontSize: 10,
                ),
              ),
              Text(
                "Definations and Key Terms\n"
                "\n To Help explain Things As clearly as possible in this privacy "
                "policy,every time any of these terms are referenced are strictly define as:",
                style: TextStyle(
                  color: Colors.redAccent,
                  fontFamily: "Abel",
                  fontWeight: FontWeight.w200,
                  fontSize: 10,
                ),
              ),
              Text(
                "\n\nCompany: when this policy mentions 'Company'.it "
                " refer to the Cracker.AT that is responsible for"
                "your information under this privacy policy"
                "\n\nDevice:Any internet Connected device Such as a Phone ,Table "
                "Third-Party Service: Refes to advertisers,contest sponsors.promotional"
                "and marketing partners,and orthers"
                "who provide our content or whose products or Services we think may interest you"
                "\n\nWebSite: SelfDeveloper.com ,which can be accessed via this URl:'www.Selfdeveloper.com'"
                "\n\nyou:A person or entity that is Registered with Cracker.AT to use the Service",
                style: TextStyle(
                  color: Colors.redAccent,
                  fontFamily: "Abel",
                  fontWeight: FontWeight.w200,
                  fontSize: 10,
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Text(
                "v1.0 ",
              ),
              Text(
                "@copyright SelfDevelopers | All right received",
                style: TextStyle(
                  color: Colors.black,
                  fontFamily: "Roboto",
                  fontWeight: FontWeight.w700,
                  fontSize: 10,
                ),
              )
            ],
          ),
        ),
      ),
    ));
  }
}
