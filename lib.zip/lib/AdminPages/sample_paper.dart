import 'package:dimagkharab/smaplepapers/capgeminipaper.dart';
import 'package:dimagkharab/smaplepapers/cognizantpaper.dart';
import 'package:dimagkharab/smaplepapers/infosyspaper.dart';
import 'package:dimagkharab/smaplepapers/technovertpaper.dart';
import 'package:dimagkharab/smaplepapers/wipropaper.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SampleAdmin extends StatefulWidget {
  @override
  _SampleAdminState createState() => _SampleAdminState();
}

class _SampleAdminState extends State<SampleAdmin> {
  admin() {
    FirebaseAuth _firebase = FirebaseAuth.instance;
    // Future<String> uid = _firebase.currentUser().then((user) => user.uid);
    // Uid = uid.toString();
    _firebase
        .isSignInWithEmailLink("project.work@gmail.com")
        .then((value) => visible = true);
  }

  bool visible = false;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ListView(children: <Widget>[
          Card(
            child: RaisedButton(
              onPressed: () {
                admin();
                print(visible);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: ((context) =>
                            Capgeminipaper(value: visible))));
              },
              child: Text("Capgemini"),
            ),
          ),
          Card(
            child: RaisedButton(
              onPressed: () {
                admin();
                print(visible);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: ((context) =>
                            CognizantPaper(value: visible))));
              },
              child: Text("congnizant"),
            ),
          ),
          Card(
            child: RaisedButton(
              onPressed: () {
                admin();
                print(visible);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: ((context) => Infosyspaper(value: visible))));
              },
              child: Text("infosys"),
            ),
          ),
          Card(
            child: RaisedButton(
              onPressed: () {
                admin();
                print(visible);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: ((context) => Wipropaper(value: visible))));
              },
              child: Text("Wipro"),
            ),
          ),
          Card(
            child: RaisedButton(
              onPressed: () {
                admin();
                print(visible);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: ((context) =>
                            Technovertpaper(value: visible))));
              },
              child: Text("technovert"),
            ),
          ),
        ]),
      ),
    );
  }
}
