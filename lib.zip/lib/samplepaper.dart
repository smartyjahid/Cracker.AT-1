import 'package:dimagkharab/companies/cognizant.dart';
import 'package:dimagkharab/smaplepapers/capgeminipaper.dart';
import 'package:dimagkharab/smaplepapers/cognizantpaper.dart';
import 'package:dimagkharab/smaplepapers/infosyspaper.dart';
import 'package:dimagkharab/smaplepapers/wipropaper.dart';
import 'package:flutter/material.dart';
import 'package:dimagkharab/companies/infosys.dart';
import 'package:dimagkharab/companies/capgemini.dart';
import 'package:dimagkharab/companies/wipro.dart';

class Samplepaper extends StatefulWidget {
  @override
  _SamplepaperState createState() => _SamplepaperState();
}

class _SamplepaperState extends State<Samplepaper> {
  List<String> names = [
    "Infosys",
    "Capgemini",
    "Wipro",
    "Cognizant",
    "Mindtree",
    "Hexaware"
  ];
  List<String> images = [
    'https://pbs.twimg.com/profile_images/1278579410795261952/EmaLJo-9_400x400.jpg',
    'https://capgeminielection.azurewebsites.net/capgemini-icon%20darkest.png',
    'https://images.newindianexpress.com/uploads/user/imagelibrary/2020/4/29/w600X390/WIPRO_Logo.jpg',
    'https://edu.kanban.university/sites/default/files/styles/large/public/company_logo/edu_website_logo_cognizant-01.png?itok=0Wf_nJRn',
    'https://i.cdn.newsbytesapp.com/images/l170_9601561551304.jpg',
    'https://hmgstrategy1.blob.core.windows.net/hmgfiles/images/default-source/logos/hexaware-logo.jpg?sfvrsn=488b89f5_0',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xFFEEEEEE),
        appBar: AppBar(
          backgroundColor: Color(0xFF5C6BC0),
          title: Text("Sample Paper"),
        ),
        body: Container(
          child: ListView.builder(
            itemBuilder: (_, index) =>
                EachEvery(this.names[index], this.images[index]),
            itemCount: this.names.length,
          ),
        ));
  }
}

class EachEvery extends StatelessWidget {
  final String name;
  int index;
  EachEvery(this.name, this.image);
  final String image;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        switch (name) {
          case "Infosys":
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: ((context) => Infosyspaper()),
                ));
            break;
          case "Capgemini":
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: ((context) => Capgeminipaper()),
                ));
            break;
          case "Wipro":
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: ((context) => Wipropaper()),
                ));
            break;
          case "Cognizant":
            Navigator.push(context,
                MaterialPageRoute(builder: ((context) => CognizantPaper())));
        }
      },
      child: Expanded(
        child: Container(
          child: Card(
            child: Container(
              padding: EdgeInsets.all(20.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  SizedBox(
                    width: 10,
                  ),
                  Text(
                    name,
                    style: TextStyle(fontSize: 15.0),
                  ),
                  SizedBox(
                    width: 100,
                  ),
                  Container(
                    width: 140,
                    height: 100,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24.0),
                      child: Image(
                          height: 50,
                          width: 50,
                          fit: BoxFit.contain,
                          alignment: Alignment.topLeft,
                          image: NetworkImage(image)),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
