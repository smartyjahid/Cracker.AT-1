import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:dimagkharab/Admin_page.dart';
import 'package:dimagkharab/Resume/ResumeDetails.dart';
import 'package:dimagkharab/Resume/ResumeView.dart';
import 'package:dimagkharab/newsapi.dart';
import 'package:dimagkharab/newuser_screen.dart';
import 'package:dimagkharab/samplepaper.dart';
import 'package:dimagkharab/userscreen.dart';
import "package:flutter/material.dart";
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'forget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:dimagkharab/signin.dart';
import 'package:flutter/cupertino.dart';
import 'dashboard.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();

  String _email, _password;
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  @override
  void dispose() {
    password.dispose();
    super.dispose();
  }

  bool show;
  void initState() {
    show = false;
    super.initState();
  }

  Widget build(BuildContext context) {
    //TextStyle textStyle = Theme.of(context).textTheme.title;

    return WillPopScope(
      onWillPop: _onpressedback,
      child: Scaffold(
          body: Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, colors: [
          Colors.blueAccent,
          Colors.lightBlue,
          Colors.blue[700],
          Colors.blueGrey,
        ])),
        child: Expanded(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: getImage(),
              ),
              Expanded(
                  child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(40),
                      topRight: Radius.circular(40)),
                ),
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          padding: EdgeInsets.all(15),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(40),
                                  topRight: Radius.circular(40)),
                              boxShadow: [
                                BoxShadow(
                                    color: Color.fromRGBO(225, 95, 27, .3),
                                    blurRadius: 20,
                                    offset: Offset(0, 10)),
                              ]),
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                Text(
                                  "Login",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontFamily: "Roboto",
                                    fontWeight: FontWeight.w700,
                                    fontSize: 30,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    "Welcome Back ",
                                    textAlign: TextAlign.start,
                                    style: TextStyle(
                                      color: Colors.green,
                                      fontFamily: "Abel",
                                      fontWeight: FontWeight.w200,
                                      fontStyle: FontStyle.italic,
                                      fontSize: 15,
                                    ),
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      border: Border(
                                          bottom: BorderSide(
                                              color: Colors.grey[200]))),
                                  child: Form(
                                    key: _formkey,
                                    //margin: EdgeInsets.all(20.0),
                                    child: Column(
                                      children: <Widget>[
                                        TextFormField(
                                          validator: (input) {
                                            if (input.isEmpty) {
                                              return 'Please type an email';
                                            }
                                            return null;
                                          },
                                          onChanged: (value) {
                                            setState(() {
                                              _email = value;
                                            });
                                          },
                                          decoration: InputDecoration(
                                            labelText: 'Email',
                                            hintText: 'Enter your email id ',
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 5),
                                          child: TextFormField(
                                              validator: (input) {
                                                if (input.length < 6) {
                                                  return 'Your password should be of six characters';
                                                }
                                                return null;
                                              },
                                              onChanged: (value) {
                                                setState(() {
                                                  _password = value;
                                                });
                                              },
                                              obscureText: !show,
                                              decoration: InputDecoration(
                                                labelText: 'Password',
                                                hintText:
                                                    'Enter your password ',
                                                suffixIcon: GestureDetector(
                                                  onTap: () {
                                                    setState(() {
                                                      show = !show;
                                                    });
                                                  },
                                                  child: Icon(
                                                    show
                                                        ? Icons.visibility
                                                        : Icons.visibility_off,
                                                  ),
                                                ),
                                              )),
                                        ),
                                        SizedBox(
                                          height: 20,
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(
                                              top: 10.0,
                                              bottom: 10.0,
                                              left: 50.0,
                                              right: 50.0),
                                          child: FlatButton(
                                            child: Text(
                                              " Forgot password ?",
                                              style: TextStyle(
                                                color: Colors.grey,
                                              ),
                                            ),
                                            onPressed: () {
                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: ((context) =>
                                                        Forget()),
                                                  ));
                                            },
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(
                                            bottom: 20.0,
                                          ),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(50),
                                            ),
                                            child: RaisedButton(
                                                color: Colors.orange[900],
                                                elevation: 3.0,
                                                focusElevation: 10.0,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          30.0),
                                                ),
                                                focusColor: Colors.blue,
                                                textColor: Colors.white,
                                                child: Text(
                                                  "Login",
                                                  style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                                onPressed: () async {
                                                  print("done");

                                                  LogIn();
                                                }),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 60,
                        ),
                        Text(
                          "Register Here !",
                          style: TextStyle(color: Colors.grey),
                        ),
                        RaisedButton(
                          color: Colors.blue,
                          textColor: Colors.white,
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: ((context) => SignIn()),
                                ));
                          },
                          child: Text(
                            "Create new account",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              )),
            ],
          ),
        ),
      )),
    );
  }

  Future<void> LogIn() async {
    void err(BuildContext context) {
      var alertDialog = AlertDialog(
        title: Text(" OOPS !!!"),
        content: Text(" You don't have an account "),
      );
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return alertDialog;
          });
    }

    final formState = _formkey.currentState;
    if (formState.validate()) {
      formState.save();
      try {
        FirebaseUser user = (await FirebaseAuth.instance
                .signInWithEmailAndPassword(email: _email, password: _password))
            .user;

        if (user != null) {
          SharedPreferences prefs = await SharedPreferences.getInstance();
          prefs.setString('email', _email);
          prefs.setString('password', _password);
          print("email" + _email);
        }

        // ignore: unused_local_variable
        FirebaseAuth auth = FirebaseAuth.instance;
        FirebaseAuth _firebase = FirebaseAuth.instance;
        FutureOr<String> uid =
            await _firebase.currentUser().then((user) => user.uid);

        Firestore.instance
            .collection("crackerdetails")
            .document(uid.toString())
            .collection("using")
            .getDocuments()
            .then((docs) {
          if (docs.documents[0].exists) {
            setState(() {});
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (context) => ButtomDash()));
          }
        });

        // CircularProgressIndicator();
        if (user.email == 'project.work@gmail.com' && _password == '12345678') {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => AdminPage()));
        } else {
          //  var context2 = context;
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (context) => LoginPage()));
        }
      } catch (e) {
        err(context);
      }
    }
  }

  Future<bool> _onpressedback() {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Are You Want To Exit ?"),
        actions: <Widget>[
          FlatButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text("no")),
          FlatButton(onPressed: () => SystemNavigator.pop(), child: Text("yes"))
        ],
      ),
    );
  }

  Widget getImage() {
    AssetImage assetImage = AssetImage('images/atproject.png');
    Image image = Image(
      image: assetImage,
      width: 150.0,
      height: 150.0,
    );
    return Container(
      child: image,
      margin: EdgeInsets.only(top: 50.0, bottom: 20.0, left: 20.0, right: 20.0),
    );
  }
}

class ButtomDash extends StatefulWidget {
  @override
  _ButtomDashState createState() => _ButtomDashState();
}

class _ButtomDashState extends State<ButtomDash> {
  int _selectedindex = 2;

  List<Widget> list = [
    Samplepaper(),
    ResumeView(),
    dashboard(),
    NewsApi(),
    newuser(),
  ];
  PageController _controller = PageController();
  _onpagechanged(int index) {
    setState(() {
      _selectedindex = index;
    });
  }

  // ignore: missing_return
  void _onitemTaped(int selectedindex) {
    setState(() {
      _controller.jumpToPage(selectedindex);
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onpressedback,
      child: Scaffold(
        bottomNavigationBar: CurvedNavigationBar(
          color: Colors.orange,
          backgroundColor: Colors.white,
          buttonBackgroundColor: Colors.white,
          height: 50,
          index: 2,
          onTap: _onitemTaped,
          items: [
            Padding(
              padding: const EdgeInsets.only(top: 15),
              child: Column(children: [
                Icon(
                  Icons.library_books,
                  size: 20,
                ),
                Text("Notes", style: TextStyle(fontSize: 10))
              ]),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 15, bottom: 5),
              child: Column(children: [
                Icon(
                  Icons.details,
                  size: 20,
                ),
                Text(
                  "Resume",
                  style: TextStyle(fontSize: 10),
                )
              ]),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Column(children: [Icon(Icons.home), Text("Home")]),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 15),
              child: Column(children: [
                Icon(
                  Icons.accessibility_new,
                  size: 20,
                ),
                Text("News", style: TextStyle(fontSize: 10))
              ]),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 15),
              child: Column(children: [
                Icon(
                  Icons.person,
                  size: 20,
                ),
                Text("Profile", style: TextStyle(fontSize: 10))
              ]),
            ),
          ],
        ),
        body: PageView(
          onPageChanged: _onpagechanged,
          controller: _controller,
          children: list,
          physics: NeverScrollableScrollPhysics(),
        ),
      ),
    );
  }

  Future<bool> _onpressedback() {
    return showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Are You Want To Exit ?"),
        actions: <Widget>[
          FlatButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text("no")),
          FlatButton(onPressed: () => SystemNavigator.pop(), child: Text("yes"))
        ],
      ),
    );
  }
}
