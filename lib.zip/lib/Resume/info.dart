class Detail {
  // personal info

  final String fullname;
  final String address;
  final String city;
  final String state;
  // contact info
  final String email;
  final String phone;
  //education details
  final String stream;
  final String branch;
  final String collage;
  final String startyear;
  String endyear;
  // compney
  String compney;
  String sDate;
  String eDate;
  String decp;
  //skill
  String skill;
  String status;
  //Experince

  Detail({
    this.stream,
    this.city = "",
    this.state = "",
    this.fullname = "",
    this.email = '',
    this.phone = '',
    this.address = '',
    this.branch,
    this.skill,
    this.status,
    this.collage = '',
    this.startyear = '',
    this.endyear = " ",
    this.compney = '',
    this.eDate = '',
    this.sDate = '',
    this.decp = '',
  });

  Map<String, dynamic> toMap() {
    return {
      "fullname": this.fullname,
      "stream": this.stream,
      "branch": this.branch,
      "status": this.status,
      "skill": this.skill,
    };
  }
}
