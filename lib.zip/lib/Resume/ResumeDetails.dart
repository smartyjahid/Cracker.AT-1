import 'dart:io';

import 'package:dimagkharab/Resume/info.dart';

import 'package:dropdownfield/dropdownfield.dart';
import 'package:fa_stepper/fa_stepper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:flutter_full_pdf_viewer/full_pdf_viewer_scaffold.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class ResumeDatail extends StatefulWidget {
  @override
  _ResumeDatailState createState() => _ResumeDatailState();
}

// pdf save
onsave() async {
  var a = 1;
  Directory mainDirectory = await getApplicationDocumentsDirectory();
  String documents = mainDirectory.path;
  File file = File("$documents/example11.pdf");
  file.writeAsBytesSync(doc.save());
  a = a + 1;
}

// initial value
class _ResumeDatailState extends State<ResumeDatail> {
  final fullname = TextEditingController();
  final address = TextEditingController();
  final city = TextEditingController();
  final state = TextEditingController();
  final email = TextEditingController();
  final mob = TextEditingController();
  final branch = TextEditingController();
  final stream = TextEditingController();
  final collage = TextEditingController();
  final syear = TextEditingController();
  final eyear = TextEditingController();

  String _fullname,
      _city,
      _state,
      _email,
      _mob,
      _address,
      _branch,
      _stream,
      _collage,
      _eyear,
      _syear;

  personal() {
    print(_fullname);
    print(_address);
    print(_city);
    print(_state);
    print(_email);
    print(_mob);
    print(_branch);
    print(_stream);
    print(_collage);
    print(_syear);
    print(_eyear);
  }
// dynamic inputs call function

  List<DynamicWidget> listinput = [];
  List<Experence> exprence = [];
  List<Experence> forms = [];

  List<String> skill = List();
  List<String> status = List();
//submitskillprint
  Future submitData() async {
    listinput.forEach((widget) {
      skill.clear();
      status.clear();
      skill.add(widget.dynamicSkill.text);
      status.add(widget.Statuss.text);
    });
  }

  // exprenceprint
  // fetchexprence() {
  //   forms.forEach((widget) {

  //   });
  // }

//addnputskill
  addInput() {
    setState(() {
      listinput.add(DynamicWidget());
    });
  }

//addinputsExperince
  addInputs() {
    setState(() {
      exprence.add(Experence());
    });
  }
  //exprenceField

  void onDelate(int index) {
    setState(() {
      exprence.removeAt(index);
    });
  }

//validation in experice
  void onSave() {
    forms.forEach((widget) {
      print(widget.form);
    });
  }

  int _currentStep = 0;

  @override
  Widget build(BuildContext context) {
    forms.clear();
    for (int i = 0; i < exprence.length; i++) {
      forms.add(Experence(
        key: GlobalKey(),
        details: Detail(),
        onDelate: () => onDelate(i),
      ));
    }
    return Scaffold(
      appBar: AppBar(
        title: Text("Enter Detail"),
      ),
      body: FAStepper(
        titleHeight: 120.0,
        type: FAStepperType.horizontal,
        steps: _stepper(),
        stepNumberColor: Colors.cyanAccent,
        physics: ClampingScrollPhysics(),
        currentStep: this._currentStep,
        onStepTapped: (step) {
          setState(() {
            this._currentStep = step;
          });
        },
        onStepContinue: () async {
          if (this._currentStep < this._stepper().length - 1) {
            this._currentStep = this._currentStep + 1;
          } else {
            await submitData();
            await genRem();
            await onsave();
            var a = 1;
            Directory mainDirectory = await getApplicationDocumentsDirectory();
            String documents = mainDirectory.path;
            String fullPath = "$documents/example11.pdf";
            print(fullPath);
            print(skill);
            print(status);
            a = a++;
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => Viewer(
                          path: fullPath,
                        )));
          }
        },
        onStepCancel: () {
          setState(() {
            if (this._currentStep > 0) {
              this._currentStep = this._currentStep - 1;
            } else {
              this._currentStep = 0;
            }
          });
        },
      ),
    );
  }

// pages....... of Resume......
  List<FAStep> _stepper() {
    List<FAStep> steps = [
      // 1
      FAStep(
        title: Row(
          children: [
            Icon(Icons.person),
            Text("Personal Datail"),
          ],
        ),
        content: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
              child: TextFormField(
                onSaved: (input) => _fullname = input,
                onChanged: (value) {
                  this._fullname = value;
                },
                decoration: InputDecoration(
                    labelText: "full Name",
                    hintText: " Enter your Full name ",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0))),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
              child: TextFormField(
                controller: address,
                onSaved: (input) => _address = input,
                onChanged: (value) {
                  this._address = value;
                },
                decoration: InputDecoration(
                    labelText: "Address",
                    hintText: " Enter your Address",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0))),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
              child: TextFormField(
                controller: city,
                onSaved: (input) => _city = input,
                onChanged: (value) {
                  this._city = value;
                },
                decoration: InputDecoration(
                    labelText: "City",
                    hintText: " Enter your city.. ",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0))),
              ),
            ),
            Padding(
                padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
                child: TextFormField(
                  controller: state,
                  onSaved: (input) => _state = input,
                  onChanged: (value) {
                    this._state = value;
                  },
                  decoration: InputDecoration(
                      labelText: "State",
                      hintText: "Ex. madhya pradesh.",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15.0))),
                )),
          ],
        ),
        isActive: _currentStep >= 0,
        state: FAStepstate.complete,
      ),
      FAStep(
        //2
        title: Row(
          children: [
            Icon(
              Icons.mobile_screen_share,
              color: Colors.brown,
            ),
            Text("Contact Info"),
          ],
        ),
        content: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
              child: TextFormField(
                controller: email,
                onSaved: (input) => _email = input,
                onChanged: (value) {
                  this._email = value;
                },
                decoration: InputDecoration(
                    labelText: "Enter your Email",
                    hintText: "Ex. xyz@gmail.com",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0))),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
              child: TextFormField(
                controller: mob,
                onSaved: (input) => _mob = input,
                onChanged: (value) {
                  this._mob = value;
                },
                decoration: InputDecoration(
                    labelText: "mobile number",
                    hintText: "Ex. 91111******",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0))),
              ),
            ),
          ],
        ),
        isActive: _currentStep >= 1,
        state: FAStepstate.editing,
      ),
      FAStep(
        title: Row(
          children: [
            Icon(
              Icons.library_books,
              color: Colors.blue,
            ),
            Text('Education Datail'),
          ],
        ),
        content: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
              child: TextFormField(
                controller: stream,
                onSaved: (input) => _stream = input,
                onChanged: (value) {
                  this._stream = value;
                },
                decoration: InputDecoration(
                    labelText: "Your Stream",
                    hintText: "Ex. B.Tech, B.Sc etc...",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0))),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
              child: TextFormField(
                controller: branch,
                onSaved: (input) => _branch = input,
                onChanged: (value) {
                  this._branch = value;
                },
                decoration: InputDecoration(
                    labelText: "Branch",
                    hintText: "Ex. information Technology etc..",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0))),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
              child: TextFormField(
                controller: collage,
                onSaved: (input) => _collage = input,
                onChanged: (value) {
                  this._collage = value;
                },
                decoration: InputDecoration(
                    labelText: "Collage",
                    hintText: "Ex. Rustamji institute of Technology..",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0))),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
                  child: Container(
                    width: 150,
                    child: TextFormField(
                      controller: syear,
                      keyboardType: TextInputType.datetime,
                      onSaved: (input) => _syear = input,
                      onChanged: (value) {
                        this._syear = value;
                      },
                      decoration: InputDecoration(
                          labelText: "Start Year",
                          hintText: "Ex. 2018",
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15.0))),
                    ),
                  ),
                ),
                Container(
                  width: 200.0,
                  child: TextFormField(
                    controller: eyear,
                    keyboardType: TextInputType.datetime,
                    onSaved: (input) => _eyear = input,
                    onChanged: (value) {
                      this._eyear = value;
                    },
                    decoration: InputDecoration(
                        labelText: "end Year",
                        hintText: "Ex. 2022",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.0))),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),

      FAStep(
        title: Row(
          children: [
            Icon(
              Icons.art_track,
              color: Colors.yellow,
            ),
            Text("Skill"),
          ],
        ),
        content: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Container(
                  child: RaisedButton(
                    color: Colors.blueAccent,
                    onPressed: () {
                      addInput();
                    },
                    child: Text(
                      "+ add",
                      style: TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 400,
              child: Flexible(
                child: ListView.builder(
                    itemCount: listinput.length,
                    itemBuilder: (_, index) => listinput[index]),
              ),
            ),
          ],
        ),
        state: FAStepstate.editing,
      ),
      FAStep(
        title: Row(
          children: [
            Icon(
              Icons.work,
              color: Colors.red,
            ),
            Text("Work_experince"),
          ],
        ),
        content: Column(
          children: <Widget>[
            Container(
              alignment: Alignment.topLeft,
              child: RaisedButton(
                onPressed: () {
                  addInputs();
                },
                child: Text(
                  "+ add",
                  style: TextStyle(
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 450,
              child: Flexible(
                child: ListView.builder(
                    itemCount: forms.length, itemBuilder: (_, i) => forms[i]),
              ),
            ),
          ],
        ),
        state: FAStepstate.editing,
      ),
    ];
    return steps;
  }

  List<DynamicWidget> listSkill = [];

  //pdf Template .............................................{}
  Future genRem() async {
    final pw.PageTheme pageTheme = await _myPageTheme(PdfPageFormat.a4);

    String name = _fullname;
    String address = _address;
    String state = _state;
    String city = _city;
    String mob = _mob;
    String email = _email;
    List<String> _skill = skill;
    // List<String> _status = status;

    List<DynamicWidget> listSkill = [];

    doc.addPage(pw.MultiPage(
        pageTheme: pageTheme,
        build: (pw.Context context) => [
              pw.Partitions(children: [
                pw.Partition(
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: <pw.Widget>[
                      pw.Container(
                          padding:
                              const pw.EdgeInsets.only(left: 30, bottom: 20),
                          child: pw.Column(children: <pw.Widget>[
                            pw.Text(name,
                                textScaleFactor: 2,
                                style: pw.Theme.of(context)
                                    .defaultTextStyle
                                    .copyWith(fontWeight: pw.FontWeight.bold)),
                            pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 10)),
                            pw.Row(
                                crossAxisAlignment: pw.CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    pw.MainAxisAlignment.spaceBetween,
                                children: <pw.Widget>[
                                  pw.Column(
                                      crossAxisAlignment:
                                          pw.CrossAxisAlignment.start,
                                      children: <pw.Widget>[
                                        pw.Text(address),
                                        pw.Text(city),
                                        pw.Text(state),
                                      ]),
                                  pw.Column(
                                      crossAxisAlignment:
                                          pw.CrossAxisAlignment.start,
                                      children: <pw.Widget>[
                                        pw.Text("+91-$mob"),
                                        pw.Text(email),
                                        //  pw.Text("JahidK828gmail.com"),
                                      ]),
                                  pw.Padding(padding: pw.EdgeInsets.zero)
                                ]),
                          ])),
                      _Category(title: 'work Experience'),
                      //      _Block(title: compney),
                      pw.SizedBox(height: 20),
                      _Category(title: 'Education'),
                      _Block(title: 'Bachelor Of Commerce'),
                    ],
                  ),
                ),
                pw.Partition(
                    width: sep,
                    child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.center,
                        children: <pw.Widget>[
                          pw.Container(
                              height: pageTheme.pageFormat.availableHeight,
                              child: pw.Column(children: [
                                pw.Text("Skills"),
                                pw.Padding(
                                  padding: const pw.EdgeInsets.only(
                                      top: 30.0, bottom: 20.0),
                                  child: pw.ListView.builder(
                                      itemBuilder: (ctx, index) {
                                        return pw.Text(_skill[index]);
                                      },
                                      itemCount: _skill.length),
                                )
                              ])),
                        ]))
              ])
            ]));
  }
}

//skill.............................................................................!
// ignore: must_be_immutable
class DynamicWidget extends StatelessWidget {
  TextEditingController dynamicSkill = TextEditingController();
  // ignore: non_constant_identifier_names
  TextEditingController Statuss = TextEditingController();
  // ignore: non_constant_identifier_names
  String SlectStatus = "";

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
          child: TextFormField(
            controller: dynamicSkill,
            decoration: InputDecoration(
                labelText: "Enter Your Skills",
                hintText: "Ex.web developer ,app developer etc.",
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.0))),
          ),
        ),
        Padding(
          padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
          child: DropDownField(
            controller: Statuss,
            labelText: "Select Status",
            hintText: "Ex. 'pro' etc",
            items: Status,
            enabled: true,
            onValueChanged: (value) {
              SlectStatus = value;
            },
          ),
        )
      ],
    );
  }

  // ignore: non_constant_identifier_names
  List<String> Status = [
    "Begainner",
    "Basic",
    "Intermediate",
    "Advance",
  ];
}
// Work_Experince.......................................

typedef OnDelate();

class Experence extends StatefulWidget {
  final Detail details;
  final state = _ExperenceState();
  final OnDelate onDelate;
  Experence({Key key, this.details, this.onDelate}) : super(key: key);
  final form = GlobalKey<FormState>();
  bool isvalid() => state.validate();
  @override
  _ExperenceState createState() => _ExperenceState();
}

class _ExperenceState extends State<Experence> {
  bool checkval = false;

  String sDate, eDate;
  TextEditingController compney = TextEditingController();
  TextEditingController sdate = TextEditingController();
  TextEditingController edate = TextEditingController();
  TextEditingController description = TextEditingController();

  final form = GlobalKey<FormState>();
  String _compney;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Card(
        child: Form(
            key: form,
            child: Column(
              children: [
                SizedBox(
                  height: 30,
                  child: AppBar(
                    leading: Icon(Icons.work),
                    title: Text('Enter Experince Detail'),
                    actions: [
                      IconButton(
                          icon: Icon(Icons.delete_outline),
                          onPressed: () {
                            widget.onDelate();
                          })
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
                  child: TextFormField(
                //    keyboardType: TextInputType.datetime,
                    onSaved: (input) =>
                        compney = input as TextEditingController,
                    onChanged: (value) => widget.details.compney = value,
                    decoration: InputDecoration(
                        labelText: "Compeney Name",
                        hintText: "Ex.vzaro ,Wipro etc.",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.0))),
                  ),
                ),
                SizedBox(
                  width: 500.0,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.only(bottom: 10.0),
                        child: SizedBox(
                          width: 150.0,
                          child: TextFormField(
                            initialValue: widget.details.sDate,
                            keyboardType: TextInputType.datetime,
                            //   onSaved: (input) => widget.details.sDate = input,
                            onChanged: (value) => widget.details.sDate = value,
                            // onChanged: (value) {
                            //   this._branch = value;
                            //  },
                            decoration: InputDecoration(
                                labelText: "Start Date",
                                hintText: "01/01/2020",
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15.0))),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 150.0,
                        child: Column(
                          children: [
                            Padding(padding: EdgeInsets.only(bottom: 10.0)),
                            SizedBox(
                              height: 50,
                              child: TextFormField(
                                // controller: branch,
                                keyboardType: TextInputType.datetime,
                                maxLengthEnforced: true,
                                maxLength: checkval == false ? 20 : 1,
                                readOnly: checkval,

                                initialValue: widget.details.eDate,

                                onSaved: (input) =>
                                    widget.details.eDate = input,
                                decoration: InputDecoration(
                                    labelText: "end Date",
                                    hintText: "01/01/2021",
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(15.0))),
                              ),
                            ),
                            Row(
                              children: [
                                Checkbox(
                                    value: checkval,
                                    onChanged: (bool value) {
                                      setState(() {
                                        checkval = value;
                                        print(value);
                                      });
                                    }),
                                Text("present"),
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 10.0, bottom: 10.0),
                  child: TextFormField(
                    initialValue: widget.details.decp,
                    keyboardType: TextInputType.datetime,
                    onSaved: (input) => widget.details.decp = input,
                    maxLength: 300,
                    maxLines: 3,
                    decoration: InputDecoration(
                        labelText: "Description",
                        hintText: "Ex.position,work etc..",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.0))),
                  ),
                )
              ],
            )),
      ),
    );
  }

  bool validate() {
    var valid = form.currentState.validate();
    if (valid) form.currentState.save();
    return valid;
  }
}

const PdfColor green = PdfColor.fromInt(0xff9ce5d0);
const PdfColor lightGreen = PdfColor.fromInt(0xffcdf1e7);
const sep = 120.0;
final pw.Document doc = pw.Document(title: 'My Résumé', author: 'jahid khan');

/// theme for page
Future<pw.PageTheme> _myPageTheme(PdfPageFormat format) async {
  format = format.applyMargin(
      left: 2.0 * PdfPageFormat.cm,
      top: 4.0 * PdfPageFormat.cm,
      right: 2.0 * PdfPageFormat.cm,
      bottom: 2.0 * PdfPageFormat.cm);
  return pw.PageTheme(
    pageFormat: format,
    theme: pw.ThemeData.withFont(
      base: pw.Font.ttf(await rootBundle.load('fonts/Abel-Regular.ttf')),
      bold: pw.Font.ttf(await rootBundle.load('fonts/Abel-Regular.ttf')),
    ),
    buildBackground: (pw.Context context) {
      return pw.FullPage(
        ignoreMargins: true,
        child: pw.CustomPaint(
          size: PdfPoint(format.width, format.height),
          painter: (PdfGraphics canvas, PdfPoint size) {
            context.canvas
              ..setColor(lightGreen)
              ..moveTo(0, size.y)
              ..lineTo(0, size.y - 230)
              ..lineTo(60, size.y)
              ..fillPath()
              ..setColor(green)
              ..moveTo(0, size.y)
              ..lineTo(0, size.y - 100)
              ..lineTo(100, size.y)
              ..fillPath()
              ..setColor(lightGreen)
              ..moveTo(30, size.y)
              ..lineTo(110, size.y - 50)
              ..lineTo(150, size.y)
              ..fillPath()
              ..moveTo(size.x, 0)
              ..lineTo(size.x, 230)
              ..lineTo(size.x - 60, 0)
              ..fillPath()
              ..setColor(green)
              ..moveTo(size.x, 0)
              ..lineTo(size.x, 100)
              ..lineTo(size.x - 100, 0)
              ..fillPath()
              ..setColor(lightGreen)
              ..moveTo(size.x - 30, 0)
              ..lineTo(size.x - 110, 50)
              ..lineTo(size.x - 150, 0)
              ..fillPath()
              ..setColor(green)
              ..setLineWidth(2)
              ..moveTo(
                  size.x - sep - format.marginRight + 4, format.marginBottom)
              ..lineTo(size.x - sep - format.marginRight + 4,
                  size.y - format.marginTop)
              ..strokePath();
          },
        ),
      );
    },
  );
}

class _Category extends pw.StatelessWidget {
  _Category({this.title});

  final String title;

  @override
  pw.Widget build(pw.Context context) {
    return pw.Container(
        decoration: const pw.BoxDecoration(color: lightGreen, borderRadius: 6),
        margin: const pw.EdgeInsets.only(bottom: 10, top: 20),
        padding: const pw.EdgeInsets.fromLTRB(10, 7, 10, 4),
        child: pw.Text(title, textScaleFactor: 1.5));
  }
}
// Descriptions

class _Block extends pw.StatelessWidget {
  _Block({this.title});

  final String title;

  @override
  pw.Widget build(pw.Context context) {
    return pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: <pw.Widget>[
          pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: <pw.Widget>[
                pw.Container(
                  width: 6,
                  height: 6,
                  margin: const pw.EdgeInsets.only(top: 2.5, left: 2, right: 5),
                  decoration: const pw.BoxDecoration(
                      color: green, shape: pw.BoxShape.circle),
                ),
                pw.Text(title,
                    style: pw.Theme.of(context)
                        .defaultTextStyle
                        .copyWith(fontWeight: pw.FontWeight.bold)),
              ]),
          pw.Container(
            decoration: const pw.BoxDecoration(
                border: pw.BoxBorder(left: true, color: green, width: 2)),
            padding: const pw.EdgeInsets.only(left: 10, top: 5, bottom: 5),
            margin: const pw.EdgeInsets.only(left: 5),
            child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: <pw.Widget>[]),
          ),
        ]);
  }
}
//extra for skill
// class _Percent extends pw.StatelessWidget {
//   List<DynamicWidget> skills = [];
//   List<String> skill = List();
//   List<String> status = List();

//   Future submitData() async {
//     skills.forEach((widget) {
//       skill.clear();
//       status.clear();
//       skill.add(widget.dynamicSkill.text);
//       status.add(widget.Statuss.text);
//       print(skill);
//       print(status);
//     });
//   }

//   _Percent({
//     @required this.size,
//     @required this.value,
//     this.title,
//     this.fontSize = 1.2,
//     this.color = green,
//     this.backgroundColor = PdfColors.grey300,
//     this.strokeWidth = 5,
//   }) : assert(size != null);

//   final double size;

//   final double value;

//   final pw.Widget title;

//   final double fontSize;

//   final PdfColor color;

//   final PdfColor backgroundColor;

//   final double strokeWidth;

//   @override
//   pw.Widget build(pw.Context context) {
//     final List<pw.Widget> widgets = <pw.Widget>[
//       pw.Container(
//         width: size,
//         height: size,
//         child: pw.Stack(
//           alignment: pw.Alignment.center,
//           fit: pw.StackFit.expand,
//           children: <pw.Widget>[
//             pw.Center(
//               child: pw.Text(
//                 '${(value * 100).round().toInt()}%',
//                 textScaleFactor: fontSize,
//               ),
//             ),
//             pw.CircularProgressIndicator(
//               value: value,
//               backgroundColor: backgroundColor,
//               color: color,
//               strokeWidth: strokeWidth,
//             ),
//           ],
//         ),
//       )
//     ];

//     if (title != null) {
//       widgets.add(title);
//     }

//     return pw.Column(children: widgets);
//   }
// }
//// pdf show here
///

class Viewer extends StatelessWidget {
  final String path;
  Viewer({this.path});
  @override
  Widget build(BuildContext context) {
    return PDFViewerScaffold(
      path: path,
    );
  }
}
