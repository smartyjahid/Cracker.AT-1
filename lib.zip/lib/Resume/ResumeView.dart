import 'package:dimagkharab/Resume/ResumeDetails.dart';
import 'package:flutter/material.dart';

class ResumeView extends StatefulWidget {
  @override
  _ResumeViewState createState() => _ResumeViewState();
}

class _ResumeViewState extends State<ResumeView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Created Resume"),
        ),
        body: Container(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(),
                Text("\nNo Data Found yet\n"),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.warning),
                    Text("Warning...!!\n"
                        "Work in process.."),
                  ],
                ),
                Text(
                    "\n\n note:- This Feature as under testing phase\n This will be avilable soon")
              ],
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.add),
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => ResumeDatail()));
          },
        ));
  }
}
