import 'package:dimagkharab/AdminPages/sample_paper.dart';
import 'package:dimagkharab/homepage.dart';
import 'package:dimagkharab/quiz.dart';
import 'package:dimagkharab/smaplepapers/cognizantpaper.dart';
import 'package:dimagkharab/tips.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AdminPage extends StatefulWidget {
  AdminPage() : super();
 // final String title = "Hello,Admin";
  @override
  _AdminPageState createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  
  List<String> dropname = [
    "Sample Paper",
    "Quiz",
    "Tips",
    "Model Ad",
    "updates",
  ];
  List<String> emage = [
    "https://d3i6fh83elv35t.cloudfront.net/static/2020/03/GettyImages-1130490453-1024x683.jpg",
    "https://www.elegantthemes.com/blog/wp-content/uploads/2019/04/buzzfeed-quiz.jpg",
    "https://st2.depositphotos.com/3591429/5245/i/450/depositphotos_52454503-stock-photo-arms-raised-holding-word-tips.jpg",
    "https://pubmatic.com/wp-content/uploads/2019/01/Ad-Quality-1.png",
    "https://st.depositphotos.com/1518767/2699/i/450/depositphotos_26992569-stock-photo-update-written-on-a-notepad.jpg",
  ];

  nested() {
    String camp;
    return NestedScrollView(
      headerSliverBuilder: (BuildContext context, bool innerBoxISScrolled) {
        return <Widget>[
          SliverAppBar(
            expandedHeight: 200,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              centerTitle: true,
              title: Text("Hello,Admin",
                  style: TextStyle(color: Colors.white, fontSize: 16.0)),
              background: Image.network(
                "https://www.thebalancecareers.com/thmb/hKctLkuZxqFGd3XpQCUjQBjSPjQ=/3436x2577/smart/filters:no_upscale()/school-books-on-desk--education-concept-871454068-5b548900c9e77c005b04fc8c.jpg",
                fit: BoxFit.cover,
              ),
            ),
            actions: [
              IconButton(
                  icon: Icon(Icons.exit_to_app),
                  onPressed: () async {
                    SharedPreferences prefs =
                        await SharedPreferences.getInstance();
                    prefs.remove('email');
                    print("removed");
                    signOut(context);
                  })
            ],
          ) 
        ];
      },
      body: ListView.builder(
        itemBuilder: (_, index) =>
            Adminfrist(this.dropname[index], this.emage[index]),
        itemCount: this.dropname.length,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.pinkAccent, body: nested());
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  Future<void> signOut(BuildContext context) async {
    await _firebaseAuth.signOut().then((_) {
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => HomePage()));
    });
  }
}

class Adminfrist extends StatelessWidget {
  String dropname, emage;
  int index;

  Adminfrist(this.dropname, this.emage);
  @override
  Widget build(BuildContext context) {
    bool visible = false;
    admin() {
      FirebaseAuth _firebase = FirebaseAuth.instance;
     
      _firebase
          .isSignInWithEmailLink("project.work@gmail.com")
          .then((value) => visible = true);
    }

    return GestureDetector(
        onTap: () {
          switch (dropname) {
            case "Sample Paper":
              Navigator.push(
                context,
                MaterialPageRoute(builder: ((context) => SampleAdmin())),
              );
              break;
            case "Quiz":
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: ((context) => Quiz()),
                  ));
              break;
            case "Tips":
              admin();
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: ((context) => Tips(value: visible)),
                  ));
              break;
            case "Model Ad":
              Navigator.push(context,
                  MaterialPageRoute(builder: ((context) => SampleAdmin())));
              break;
            case "update":
              Navigator.push(context,
                  MaterialPageRoute(builder: ((context) => CognizantPaper())));
          }
        },
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 200,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    colors: [
                      Colors.cyan,
                      Colors.brown,
                      Colors.deepPurpleAccent
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.cyan,
                        blurRadius: 12,
                        offset: Offset(0, 6))
                  ],
                ),
                child: SizedBox(
                  width: 500,
                  child: Row(
                    children: <Widget>[
                      SizedBox(
                        width: 20,
                      ),
                      Container(
                        width: 100,
                        height: 70,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(24.0),
                          child: Image(
                              fit: BoxFit.contain,
                              alignment: Alignment.topLeft,
                              image: NetworkImage(emage)),
                        ),
                      ),
                      SizedBox(
                        width: 60,
                      ),
                      Text(
                        dropname,
                        style: TextStyle(
                          color: Colors.white,
                          fontStyle: FontStyle.italic,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ));
  }
}
