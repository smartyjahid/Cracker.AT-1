import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:dimagkharab/Company.dart';
import 'package:dimagkharab/model.dart';
import 'package:dimagkharab/viewpdf.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

// ignore: camel_case_types
class Capgeminipaper extends StatefulWidget {
  bool value;
  Capgeminipaper({Key key, this.value}) : super(key: key);
  @override
  _CapgeminipaperState createState() => _CapgeminipaperState(value);
}

class _CapgeminipaperState extends State<Capgeminipaper> {
  bool value = false;
  _CapgeminipaperState(this.value);
  List<Model> itemList = List();
  final mainReferance =
      FirebaseDatabase.instance.reference().child('database/Capgemini');
  List<String> names = [
    "Infosys",
    "Capgemini",
    "Wipro",
    "Cognizant",
    "Mindtree",
    "Hexaware"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEEEEEE),
      appBar: AppBar(
        backgroundColor: Color(0xFF5C6BC0),
        title: Text(
          " Sample Paper ",
        ),
      ),
      body: itemList.length == 0
          ? Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                  children: [CircularProgressIndicator(), Text("\n Loading..")]))
          : ListView.builder(
              itemCount: itemList.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                  child: GestureDetector(
                    onTap: () {
                      String passData = itemList[index].link;
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Viewpdf(),
                              settings: RouteSettings(
                                arguments: passData,
                              )));
                    },
                    child: Stack(
                      children: <Widget>[
                        Container(
                          height: 140,
                          decoration: BoxDecoration(color: Colors.blueAccent),
                        ),
                        Center(
                          child: Container(
                            height: 140,
                            child: Card(
                              margin: EdgeInsets.all(18),
                              elevation: 7.0,
                              child: Center(
                                child: Text(itemList[index].name +
                                    " " +
                                    (index + 1).toString()),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                );
              }),
      floatingActionButton: Visibility(
        visible: value == null ? false : value,
        child: FloatingActionButton(
          onPressed: () async {
            //     admin();
            _alertDialog();
            //    print(Uid);
          },
          child: Icon(
            Icons.picture_as_pdf,
            color: Colors.black,
          ),
        ),
      ),
    );
  }

  var pdfname;
  void _alertDialog() {
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Enter The Name"),
            content: TextField(
              onChanged: (value) => pdfname = value,
              onSubmitted: (value) => pdfname = value,
            ),
            actions: [
              FlatButton(
                onPressed: () {
                  getpdf();
                },
                child: Text("Done"),
              )
            ],
          );
        });
  }

  Future getpdf() async {
    // var rng = Random();
    // String randnme = "";
    // for (var i = 0; i < 20; i++) {
    //   print(rng.nextInt(100));
    //   randnme += rng.nextInt(100).toString();
    // }
    File file = await FilePicker.getFile(type: FileType.custom);
    var filename = '$pdfname.pdf';
    savePdf(file.readAsBytesSync(), filename);
  }

  savePdf(List<int> asset, String name) async {
    StorageReference refer = FirebaseStorage.instance.ref().child(name);
    StorageUploadTask uploadTask = refer.putData(asset);
    String url = await (await uploadTask.onComplete).ref.getDownloadURL();
    documentFileupd(url);
  }

  String createCrypttoRandomString([int length = 32]) {
    final Random _random = Random.secure();
    var values = List<int>.generate(length, (i) => _random.nextInt(256));
    return base64Url.encode(values);
  }

  void documentFileupd(String str) {
    var data = {
      "pdf": str,
      "Filename": "capgemini Sample paper",
    };
    mainReferance.child(createCrypttoRandomString()).set(data).then((v) {
      print("Store successFully");
    });
  }

  @override
  void initState() {
    super.initState();
    mainReferance.once().then((DataSnapshot snap) {
      var data = snap.value;
      itemList.clear();
      data.forEach((key, value) {
        Model m = Model(value['pdf'], value['Filename']);
        itemList.add(m);
        print(itemList);
      });
      setState(() {
        print(itemList.length);
      });
    });
  }
}
