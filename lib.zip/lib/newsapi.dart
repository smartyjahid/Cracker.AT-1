import 'package:cached_network_image/cached_network_image.dart';
import 'package:dimagkharab/pagesapies/Artical_model.dart';
import 'package:dimagkharab/pagesapies/Article.dart';
import 'package:dimagkharab/pagesapies/Article_viewer.dart';
import 'package:dimagkharab/pagesapies/Catageoryapi.dart';
import 'package:dimagkharab/pagesapies/Data.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class NewsApi extends StatefulWidget {
  @override
  _NewsApiState createState() => _NewsApiState();
}

class _NewsApiState extends State<NewsApi> {
  bool loading = true;
  List<CategoryModel> categories = List<CategoryModel>();
  List<Articlemode> articles = List<Articlemode>();

  @override
  void initState() {
    super.initState();
    categories = getCatagory();
    getNews();
  }

  getNews() async {
    NewsArt news = NewsArt();
    await news.geturl();
    articles = news.newsart;
    setState(() {
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 2.0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Cracker"),
            Text(
              "News",
              style: TextStyle(color: Colors.black),
            )
          ],
        ),
      ),
      body: loading
          ? Center(
              child: Container(
                child: CircularProgressIndicator(),
              ),
            )
          : SingleChildScrollView(
              child: Container(
                child: Column(
                  children: <Widget>[
                    Container(
                      height: 80,
                      //category.....
                      child: ListView.builder(
                          itemCount: categories.length,
                          shrinkWrap: true,
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (context, i) {
                            return Cartgorytile(
                              imageurl: categories[i].imageurl,
                              categoryname: categories[i].catagoryname,
                            );
                          }),
                    ),
                    // Blog........
                    Padding(
                      padding: const EdgeInsets.only(top: 15, bottom: 15),
                      child: Container(
                        child: ListView.builder(
                            physics: ClampingScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: articles.length,
                            itemBuilder: (context, i) {
                              return BlogTile(
                                imageUrl: articles[i].urlToImage,
                                title: articles[i].title,
                                desc: articles[i].description,
                                url: articles[i].url,
                              );
                            }),
                      ),
                    )
                  ],
                ),
              ),
            ),
    );
  }
}

class Cartgorytile extends StatelessWidget {
  final imageurl, categoryname;
  Cartgorytile({this.categoryname, this.imageurl});
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Stack(
        children: [
          CachedNetworkImage(
            imageUrl: imageurl,
            width: 120,
            height: 60,
            fit: BoxFit.cover,
          ),
          Container(
            child: Text(
              categoryname,
            ),
          ),
        ],
      ),
    );
  }
}

// ignore: must_be_immutable
class BlogTile extends StatelessWidget {
  String imageUrl, title, desc;
  String url;
  BlogTile(
      {@required this.imageUrl,
      @required this.title,
      @required this.desc,
      @required url});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ArticleView(blogUrl: imageUrl)));
      },
      child: Container(
        child: Column(
          children: <Widget>[
            ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(imageUrl)),
            SizedBox(
              height: 8,
            ),
            Text(
              title,
              style: TextStyle(
                color: Colors.black,
                fontSize: 13,
                fontStyle: FontStyle.italic,
              ),
            ),
            SizedBox(
              height: 8,
            ),
            Text(
              desc,
              style: TextStyle(
                color: Colors.black26,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
