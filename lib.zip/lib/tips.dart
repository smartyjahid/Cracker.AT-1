import 'dart:io';
import 'package:dimagkharab/Tipss.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

class Tips extends StatefulWidget {
  bool value;
  Tips({Key key, this.value}) : super(key: key);
  @override
  _TipsState createState() => _TipsState(value);
}

class _TipsState extends State<Tips> {
  _TipsState(this.value);
  bool value = false;
  List<Tipss> itemList = [];
  styles() {
    return TextStyle(
        fontSize: 10,
        fontStyle: FontStyle.italic,
        fontWeight: FontWeight.w100,
        color: Colors.indigo);
  }

  @override
  void initState() {
    super.initState();
    DatabaseReference tipsRef =
        FirebaseDatabase.instance.reference().child("tips");
    tipsRef.once().then((DataSnapshot snap) {
      var key = snap.value.keys;
      var data = snap.value;

      itemList.clear();
      for (var indikey in key) {
        Tipss tipss = Tipss(
          data[indikey]['image'],
          data[indikey]['date'],
          data[indikey]['time'],
        );
        itemList.add(tipss);
      }
      setState(() {
        print("Length: ${itemList.length}");
      });
    });
  }

  final formKey = GlobalKey<FormState>();

  String url;

  Widget viewpoint(String image, String date, String time, int i) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
      elevation: 10.0,
      margin: EdgeInsets.all(15.0),
      child: Container(
        padding: EdgeInsets.all(14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              "Tip of the day",
              style: TextStyle(
                  color: Colors.grey,
                  fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 10.5,
            ),
            ClipRRect(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(16.0),
                topRight: Radius.circular(16.0),
              ),
              child: Image.network(
                image,
                fit: BoxFit.fill,
                height: 300,
                alignment: Alignment.center,
              ),
            ),
            Padding(
                padding: const EdgeInsets.all(8.0),
                child: Flexible(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Liked(i),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            date,
                            // style: Theme.of(context).textTheme.subtitle1,
                            textAlign: TextAlign.end,
                            style: styles(),
                          ),
                          Text(
                            time,
                            // style: Theme.of(context).textTheme.subtitle2,
                            style: styles(),
                            textAlign: TextAlign.end,
                          ),
                        ],
                      )
                    ],
                  ),
                ))
          ],
        ),
      ),
    );
  }

  // ignore: non_constant_identifier_names
  File ImageFile;
  String imagename;
  Future getImage() async {
    // ignore: deprecated_member_use
    var tempImage = await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      ImageFile = tempImage;
    });
  }

  void remove() {
    setState(() {
      ImageFile = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: itemList.length == 0
            ? Center(
                child: Text(
                "No data Obtain yet , \n check internet connectivity",
                textAlign: TextAlign.center,
              ))
            : ListView.builder(
                itemCount: itemList.length,
                itemBuilder: (_, i) {
                  return viewpoint(
                      itemList[i].image, itemList[i].date, itemList[i].time, i);
                }),
      ),
      floatingActionButton: Visibility(
        visible: value == null ? false : value,
        child: FloatingActionButton(
          onPressed: () async {
            await getImage();
            await _alertDialog();
          },
          tooltip: 'upload Tips',
          child: Icon(Icons.cloud_upload),
        ),
      ),
    );
  }

  void uploadTips() async {
    final StorageReference _storage =
        FirebaseStorage.instance.ref().child("Tips");
    var timeKey = DateTime.now();

    final StorageUploadTask task =
        _storage.child(timeKey.toString() + ".jpg").putFile(ImageFile);
    var Imageurl = await (await task.onComplete).ref.getDownloadURL();
    url = Imageurl.toString();
    print("Image Url =" + url);
    saveToDatabase(url);
  }

  void saveToDatabase(url) {
    var dbTimeKey = DateTime.now();
    var formatTime = DateFormat('EEEE,hh:mm aaa');
    var formatDate = DateFormat('MMM d, yyyy');
    String date = formatDate.format(dbTimeKey);
    String time = formatTime.format(dbTimeKey);

    DatabaseReference ref = FirebaseDatabase.instance.reference();

    var data = {
      "image": url,
      "date": date,
      "time": time,
    };
    ref.child("tips").push().set(data);
  }

  // ignore: missing_return
  Future<void> _alertDialog() {
    setState(() {});
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Preview"),
            content: Expanded(
              child: Container(
                child: ImageFile != null
                    ? Expanded(
                        child: Column(children: [
                          Container(
                            child: Image.file(
                              ImageFile,
                              height: 330.0,
                              width: 600.0,
                            ),
                          ),
                        ]),
                      )
                    : Center(
                        child: Text("No Picked yet"),
                      ),
              ),
            ),
            actions: [
              FlatButton(
                onPressed: () async {
                  uploadTips();
                  remove();
                  Navigator.pop(context);
                  setState(() {});
                },
                child: Text("Done"),
              ),
              FlatButton(
                onPressed: () async {
                  Navigator.pop(context);
                  setState(() {});
                },
                child: Text("Exit"),
              )
            ],
          );
        });
  }
}

class Liked extends StatefulWidget {
  int _index;
  Liked(index) {
    _index = index;
  }

  @override
  _LikedState createState() => _LikedState();
}

class _LikedState extends State<Liked> {
  bool liked = false;
  pressed() {
    setState(() {
      liked = !liked;
    });
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
        icon: Icon(
          liked ? Icons.favorite : Icons.favorite_border,
          color: liked ? Colors.red : Colors.grey,
        ),
        onPressed: () {
          pressed();
        });
  }
}
