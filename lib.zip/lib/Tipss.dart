class Tipss {
  String image, date, time;
  Tipss(this.image, this.date, this.time);
}
